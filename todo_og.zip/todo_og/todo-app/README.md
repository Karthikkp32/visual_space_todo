# Todo List Application

A simple Todo List application built using Node.js, Express, MongoDB, and vanilla JavaScript (with HTML and CSS). This app allows users to add, edit, delete, and update the status of tasks. The tasks are stored in a MongoDB database.

## Features

- **Add Task**: Users can add a new task to the list.
- **Edit Task**: Users can edit the title of an existing task.
- **Delete Task**: Users can delete a task after confirming the deletion.
- **Task Status**: Users can toggle the task's status between "Pending" and "Completed".
- **Task Table**: All tasks are displayed in a table format with relevant details like task name, status, and actions (Edit, Delete, and Status).
- **Confirmation for Deletion**: A confirmation prompt is shown when deleting a task to prevent accidental deletions.

## Technologies Used

- **Backend**: Node.js, Express, MongoDB
- **Frontend**: HTML, CSS, JavaScript
- **Database**: MongoDB
- **Environment Variables**: .env file for storing sensitive information like MongoDB URI and port.

## Setup Instructions

### Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js**: [Download and install Node.js](https://nodejs.org/)
- **MongoDB**: [Download and install MongoDB](https://www.mongodb.com/try/download/community)

### Installation

1. Clone the repository to your local machine:

   ```bash
   git clone <repository-url>
   cd <project-folder>
   ```

2. Install the necessary dependencies:

   ```bash
   npm install
   ```

3. Create a .env file in the root directory and add your MongoDB URI and port number:

   ```bash
   MONGO_URI=mongodb://localhost:27017/todoapp
   PORT=5000
   ```

4. Start the server:

   ```bash
   npm start
   ```

   This will start the server on the specified port (default is 5000).

5. Open the app in your browser at `http://localhost:5000`.

## Folder Structure

- **models**: Contains the Task.js file that defines the schema for the tasks.
- **controllers**: Contains the TC.js file that handles the logic for fetching, adding, updating, and deleting tasks.
- **routes**: Contains the tasks.js file that defines the routes for handling requests related to tasks.
- **public**: Contains the frontend files (index.html, styles.css, script.js).
- **server.js**: The entry point of the application where the server is set up.

## How to Use

1. **Add a Task**:
   - Type the task name in the input field and click "Add Task".
   - A confirmation alert will appear, and the task will be added to the list.

2. **Edit a Task**:
   - Click the "✏️" button next to a task to edit its title.
   - Enter a new title and click "OK" to save.

3. **Delete a Task**:
   - Click the "🗑️" button next to a task to delete it.
   - A confirmation dialog will appear asking if you're sure you want to delete the task.
   - Click "OK" to confirm or "Cancel" to cancel the deletion.

4. **Toggle Task Status**:
   - Click the "✅ Mark as Completed" or "❌ Mark as Pending" button to toggle the task status between "Pending" and "Completed".

5. **View Tasks**:
   - All tasks are displayed in a table with columns for task number, task title, status, and actions.

## API Endpoints

- **GET /tasks**: Fetch all tasks.
- **POST /tasks**: Add a new task.
- **PUT /tasks/:id**: Update a task (title, comments, or status).
- **DELETE /tasks/:id**: Delete a task.

## Troubleshooting

- **MongoDB Connection Issues**: If you encounter any issues connecting to MongoDB, ensure that MongoDB is running locally on your machine. You can start MongoDB using the command:

  ```bash
  mongod
  ```

- **Port Conflicts**: If the server is not starting due to a port conflict, change the port in the .env file.

## License

This project is open-source and available under the [MIT License](LICENSE).
